package com.wpbrewery.mms.walterpenkapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalterpenkApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalterpenkApiApplication.class, args);
	}

}

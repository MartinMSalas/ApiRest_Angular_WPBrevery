package com.wpbrewery.mms.walterpenkapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalterpenkApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
